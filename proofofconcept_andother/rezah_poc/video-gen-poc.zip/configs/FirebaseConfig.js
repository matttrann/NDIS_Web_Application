// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getStorage} from 'firebase/storage';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
    authDomain: "skills4life-5dd96.firebaseapp.com",
    projectId: "skills4life-5dd96",
    storageBucket: "skills4life-5dd96.firebasestorage.app",
    messagingSenderId: "407448791819",
    appId: "1:407448791819:web:e0eb9ad126099608dd100e"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const storage=getStorage(app);