const {
    GoogleGenerativeAI,
    HarmCategory,
    HarmBlockThreshold,
} = require("@google/generative-ai");

const apiKey = process.env.NEXT_PUBLIC_GEMINI_API_KEY;
const genAI = new GoogleGenerativeAI(apiKey);

const model = genAI.getGenerativeModel({
    model: "gemini-2.0-flash-exp",
});

const generationConfig = {
    temperature: 1,
    topP: 0.95,
    topK: 40,
    maxOutputTokens: 8192,
    responseMimeType: "application/json",
};


    export const chatSession = model.startChat({
        generationConfig,
        history: [
            {
                role: "user",
                parts: [
                    {text: "Write a script to generate 30 seconds video on topic: Interesting historical story along with AI image prompt in Realistic format for each scene and give me result in JSON format with imagePrompt and ContentField as field, No Plain text."},
                ],
            },
            {
                role: "model",
                parts: [
                    {text: "```json\n[\n  {\n    \"imagePrompt\": \"A bustling marketplace in ancient Alexandria, Egypt, during the Hellenistic period. Vendors sell exotic spices, vibrant fabrics, and pottery. The Library of Alexandria looms in the background, its majestic architecture bathed in golden sunlight.  Realistic, detailed, wide-angle shot, warm color palette.\",\n    \"ContentField\": \"Narrator: (Voiceover, calm and intrigued) Imagine Alexandria, a melting pot of cultures in the ancient world. A hub of trade and knowledge, where the echoes of history still whisper today.\"\n  },\n  {\n   \"imagePrompt\": \"Close-up shot of a meticulously crafted scroll being unrolled. The script is ancient Greek, and the texture of the papyrus is visible. A scholar's hand, weathered and wise, holds the scroll. Realistic, detailed, shallow depth of field, focus on the scroll.\",\n    \"ContentField\": \"Narrator: Here, in the legendary Library of Alexandria, scholars meticulously recorded all known knowledge.  From star charts to medical treatises, this was the world's central repository of information.\"\n  },\n  {\n    \"imagePrompt\": \"A group of scholars, dressed in simple tunics, intently studying texts and discussing ideas within the library's reading room. Light filters through the high windows, illuminating the scene.  Realistic, slightly low angle, natural lighting.\",\n     \"ContentField\": \"Narrator:  For centuries, these scholars diligently worked, preserving and expanding human understanding. Their dedication fueled advancements in mathematics, astronomy, and philosophy. \"\n  },\n  {\n     \"imagePrompt\": \"A dramatic scene showing the Library of Alexandria ablaze with fire. Flames engulf the structure, and billowing smoke rises into the sky. A few figures are seen attempting to salvage scrolls amidst the chaos. Realistic, dramatic lighting, wide shot, chaotic composition.\",\n    \"ContentField\": \"Narrator: But tragedy struck. The Library was consumed by fire, a catastrophic loss to humanity. Countless scrolls, containing invaluable knowledge, were destroyed.\"\n  },\n  {\n   \"imagePrompt\": \"A single, charred scroll fragment lies amidst ashes. Close-up shot, detailed texture, somber lighting, shallow depth of field.\",\n    \"ContentField\": \"Narrator: While some remnants survived, the world lost a treasure trove of history and wisdom. The burning of the Library serves as a stark reminder of the fragility of knowledge. \"\n  },\n  {\n    \"imagePrompt\": \"A panoramic view of modern Alexandria, showing both ancient ruins and the bustling city life of today. The remnants of the past are seamlessly integrated into the present. Realistic, wide-angle shot, vibrant city scene.\",\n    \"ContentField\": \"Narrator: Yet, Alexandria still stands, a testament to human resilience. The echoes of the past continue to resonate, reminding us of the importance of preserving our collective history. \"\n  }\n\n]\n```\n"},
                ],
            },
        ],
    });
